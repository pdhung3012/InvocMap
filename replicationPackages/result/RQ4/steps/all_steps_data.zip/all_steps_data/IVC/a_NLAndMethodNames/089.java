encodingCollection.iterator().next()
return whether there are more elements in encodingCollection.iterator()
next
