ByteBuffer.wrap(bytes)
wrap bytes into a buffer for ByteBuffer
wrap
