Long.valueOf(cursor.getLong(colIndex))
return Long representation of cursor.getLong(colIndex)
valueOf
