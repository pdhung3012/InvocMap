new Integer(idAtividadeAux).intValue()
return value of new Integer(idAtividadeAux) as int for Integer
intValue
