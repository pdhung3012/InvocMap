Math.pow(-base, 1 / exponent)
return - base to the power of 1 / exponent from Math
pow
