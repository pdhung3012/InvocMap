File.createTempFile("shareimage", ".png")
create empty temporary file with name "shareimage" and suffix ".png" for File
createTempFile
