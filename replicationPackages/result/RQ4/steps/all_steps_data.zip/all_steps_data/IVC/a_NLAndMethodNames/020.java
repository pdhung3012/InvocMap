dateFormatter.format(now.getTime())
format now.getTime() into String and append to dateFormatter for SimpleDateFormat
format
173-353
https://github.com/codice/ddf-ui/blob/master/platform/metrics/platform-metrics-reporting/src/main/java/ddf/metrics/reporting/internal/rest/MetricsEndpoint.java
