rev2.getStrings().equals( TestTools.makeSet( "sse1_string1", "sse1_string2" ) )
return whether rev2.getStrings() equals TestTools.makeSet("sse1_string1","sse1_string2")
equals
