ZonedDateTime.ofInstant(calendar.toInstant(), calendar.getTimeZone().toZoneId()).toInstant()
convert ZonedDateTime.ofInstant(calendar.toInstant(), calendar.getTimeZone().toZoneId()) for ZonedDateTime
toInstant
