body.getBlock().getStatements().isEmpty()
return if body.getBlocks().getStatements() is empty
isEmpty
