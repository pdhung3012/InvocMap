cls.getSuperclass()
return super class of cls
getSuperclass
