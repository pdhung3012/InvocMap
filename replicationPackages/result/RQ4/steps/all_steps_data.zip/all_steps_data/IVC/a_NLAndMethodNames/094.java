Duration.ofMinutes(10)
return Duration of 10 minutes
ofMinutes
