remoteDomain.equals(doc.attributeValue("from"))
return whether remoteDomain is equal to doc.attributeValue("from")
equals
632-785
https://github.com/igniterealtime/Openfire/blob/master/xmppserver/src/main/java/org/jivesoftware/openfire/server/ServerDialback.java 
