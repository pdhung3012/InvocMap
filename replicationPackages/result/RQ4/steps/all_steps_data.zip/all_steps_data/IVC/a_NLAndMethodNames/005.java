xml.append(item.getAlternateLabel())
append item.getAlternateLabel() to xml
append
140-208
https://github.com/openelisglobal/openelisglobal-core/blob/develop/app/src/us/mn/state/health/lims/common/servlet/selectdropdown/AjaxXmlBuilderForSortableTests.java
