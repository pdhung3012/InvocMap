klass.getPackage().getName()
return the name of the package for klass.getPackage()
getName
