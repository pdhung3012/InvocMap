map.put("3", new Integer(1))
associate key "3" with value new Integer(1)
put
