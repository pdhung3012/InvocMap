type.equals(short.class)
return whether type equals short.class
equals
