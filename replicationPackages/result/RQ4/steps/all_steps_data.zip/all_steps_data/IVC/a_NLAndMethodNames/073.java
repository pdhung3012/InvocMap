factory.getMetamodel().collectionPersisters().values()
return all collection persisters of factory.getMetamodel().collectionPersisters()
values
