"en".equals(locale.getLanguage())
return whether "en" equals locale.getLanguage()
equals
