str.charAt(pos + 1)
return the char value at index pos + 1 for str
charAt
https://github.com/sakaiproject/sakai/blob/master/kernel/kernel-impl/src/main/java/org/sakaiproject/util/impl/FormattedTextImpl.java
Method Line: 872-977
