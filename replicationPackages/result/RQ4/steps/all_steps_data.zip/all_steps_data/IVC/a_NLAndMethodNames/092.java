object.getClass().getName().endsWith(".BuddhistCalendar")
return whether object.getClass().getName() ends with ".BuddhistCalendar" suffix
endsWith
