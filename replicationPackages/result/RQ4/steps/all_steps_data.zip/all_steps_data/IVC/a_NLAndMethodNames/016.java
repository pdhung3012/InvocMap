scriptBuffer.append(", null")
append ", null" to scriptBuffer
append
754-862
https://github.com/Bahmni/OpenElis/blob/master/openelis/src/us/mn/state/health/lims/common/valueholder/tree/TreeNode.java
