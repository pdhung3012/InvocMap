Math.max(0, container.height())
return the max of 0 and container.height()
max
