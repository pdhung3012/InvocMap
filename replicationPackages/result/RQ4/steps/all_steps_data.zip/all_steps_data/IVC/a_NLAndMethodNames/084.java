itemTexts.getHelp().length()
return length of itemTexts.getHelp()
length
