Collator.getInstance()
return current default locale Collator
getInstance
