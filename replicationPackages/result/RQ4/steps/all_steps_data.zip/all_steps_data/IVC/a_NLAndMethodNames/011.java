cal.add(Calendar.DAY_OF_YEAR, idx)
add Calendar.DAY_OF_YEAR from idx to cal
add
212-292
https://github.com/UniTime/unitime/blob/master/JavaSource/org/unitime/timetable/webutil/timegrid/TimetableGridCell.java
