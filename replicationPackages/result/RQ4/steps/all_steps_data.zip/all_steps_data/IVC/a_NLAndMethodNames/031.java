searchedElement.getQualifiedName().toString()
return String representation of searchedElement.getQualifiedName() for searchedElement
toString()
