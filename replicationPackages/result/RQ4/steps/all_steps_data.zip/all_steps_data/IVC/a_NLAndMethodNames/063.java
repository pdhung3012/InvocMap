(Class) type).isEnum()
return whether type is Enum
isEnum
