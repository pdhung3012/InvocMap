pw.print(Integer.toHexString(rec.states))
print Integer.toHexString(rec.states) for pw
print
1987-2093
https://github.com/AOKP/frameworks_base_disabled/blob/jb/core/java/android/os/BatteryStats.java
