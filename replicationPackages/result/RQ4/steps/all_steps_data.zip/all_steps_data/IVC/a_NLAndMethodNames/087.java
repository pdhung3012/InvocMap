definition.getValues().iterator()
return an Iterator for definition.getValues()
iterator
