Integer.parseInt(mTestTime.getText().toString())
convert mTestTime.getText().toString() to Integer
parseInt
