g.setColor(hRegion.textAttributes.getEffectColor())
set current context color to hRegion.textAttributes.getEffectColor() in g
setColor
202-322
https://github.com/jexp/idea2/blob/master/platform/platform-api/src/com/intellij/ui/HighlightableComponent.java
