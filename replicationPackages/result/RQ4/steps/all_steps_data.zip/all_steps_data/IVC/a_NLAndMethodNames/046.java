childList.add(linearLayout.getChildAt(i))
add linearLayout.getChildAt(i) to childList
add
