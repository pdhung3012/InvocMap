Thread.currentThread().interrupt()
interrupt Thread.currentThread()
interrupt
