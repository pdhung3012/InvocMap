Math.min(lp.height, height)
return the minimum of lp.height and height
min
