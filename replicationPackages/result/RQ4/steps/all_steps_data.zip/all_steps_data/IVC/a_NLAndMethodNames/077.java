address.toUpperCase()
convert address to uppercase
toUpperCase
