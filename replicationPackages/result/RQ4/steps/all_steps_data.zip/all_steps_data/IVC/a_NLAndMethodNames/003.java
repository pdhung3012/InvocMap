paramMap.put(paramName, Short.valueOf(value));
associate key paramName with value Short.valueOf(value) in paramMap
put
163-206
https://github.com/ironrhino/ironrhino/blob/master/src/org/ironrhino/core/jdbc/JdbcUpdateService.java
