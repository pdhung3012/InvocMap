Class.forName("com.vladium.emma.rt.RT")
return Class object associated with "com.cladium.emma.rt.RT"
forName
