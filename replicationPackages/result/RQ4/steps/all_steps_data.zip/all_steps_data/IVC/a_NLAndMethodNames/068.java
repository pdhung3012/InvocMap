UIManager.getColor("MenuItem.acceleratorForeground")
return a color from default key "MenuItem.acceleratorForeground" for UIManager
getColor
