((TreeTable)table).getTree().getPathForRow(row).getLastPathComponent()
return the last path component of ((TreeTable)table).getTree().getPathForRow(row) for table
getLastPathComponent
