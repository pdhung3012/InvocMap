buf.toString().toCharArray()
return character array of buf.toString() for buf
toCharArray
