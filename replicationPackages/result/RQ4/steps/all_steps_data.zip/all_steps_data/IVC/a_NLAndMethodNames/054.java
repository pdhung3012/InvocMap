((TextView)localView).getText().toString()
return String representation of ((TextView)localView).getText()
toString
