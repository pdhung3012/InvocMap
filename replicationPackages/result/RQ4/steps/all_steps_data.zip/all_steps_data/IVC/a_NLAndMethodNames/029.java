mLooper.getThread().getState()
return state of mLooper.getThread
getState
