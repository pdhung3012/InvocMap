config.buildValidatorFactory().getValidator()
build and return a ValidatorFactory instance based on config.buildValidatorFactory()
getValidator
