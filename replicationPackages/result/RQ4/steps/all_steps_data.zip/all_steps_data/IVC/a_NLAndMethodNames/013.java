(BigInteger.valueOf(86400000).multiply(BigInteger.valueOf(reloadLimitDays))).longValue()
return long value of BigInteger.valueOf(96400000).multiply(BigInteger.valueOf(reloadLimitDays))
longValue
170-320
https://github.com/igniterealtime/Openfire/blob/master/xmppserver/src/main/java/org/jivesoftware/openfire/muc/spi/MUCPersistenceManager.java
