mIntents.toArray(new Intent[mIntents.size()])
return array representation of mIntents with size new Intent(mIntents.size())
toArray
