return value of new Integer(idAtividateAux) as int for Integer
new Integer(idAtividadeAux).intValue()
intValue
