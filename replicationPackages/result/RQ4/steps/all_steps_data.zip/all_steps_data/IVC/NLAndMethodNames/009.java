System.out.println("Table: " + tablename);
print "Table: "+tablename to Standard Output
println
82-156
https://github.com/alkacon/opencms-core/blob/branch_11_0_x/src-setup/org/opencms/setup/db/update6to7/postgresql/CmsUpdateDBCreateIndexes7.java
