sb.append(can_access ?  iced :  iced_unsafe)
append can_access?iced:iced_unsafe to sb
append
396-503
https://github.com/h2oai/h2o-3/blob/master/h2o-core/src/main/java/water/Weaver.java
