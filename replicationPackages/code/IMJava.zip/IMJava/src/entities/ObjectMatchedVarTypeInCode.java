package entities;

public class ObjectMatchedVarTypeInCode  {
	private String fullName;
	private String className;
	private boolean isMatch=false;
	
	
	
	

	public boolean isMatch() {
		return isMatch;
	}



	public void setMatch(boolean isMatch) {
		this.isMatch = isMatch;
	}



	public String getFullName() {
		return fullName;
	}



	public void setFullName(String fullName) {
		this.fullName = fullName;
	}



	public String getClassName() {
		return className;
	}



	public void setClassName(String className) {
		this.className = className;
	}



	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
