package entities;

public class ObjectTermInNL {
	private String term="";
	private boolean isMatchTerm=false;
	public String getTerm() {
		return term;
	}
	public void setTerm(String term) {
		this.term = term;
	}
	public boolean isMatchTerm() {
		return isMatchTerm;
	}
	public void setMatchTerm(boolean isMatchTerm) {
		this.isMatchTerm = isMatchTerm;
	}
	
	
}
