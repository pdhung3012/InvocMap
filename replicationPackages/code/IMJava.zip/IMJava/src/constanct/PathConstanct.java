package constanct;


/**
 * This class stores paths of all configurations
 *
 */
public class PathConstanct {
	public static String PathLiterateProgrammingCorpus="";
	public static String PathLiterateProgrammingEvaluationOutput="";
	public static String PathLiterateProgrammingExpReplication="";
	public static String PathMachineTranslationCorpus="";
	public static String PathMachineTranslationEvalOutput="";
	
	public static String PATH_JAVA_CLASSPATH = "C:\\Program Files\\Java\\jdk1.8.0_144\\jre\\lib\\rt.jar";
	
}
