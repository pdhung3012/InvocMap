logger.finer("got request for: " + filename);
log finer message "got request for: "+filename for logger
finer
405-472
https://github.com/CSEMike/OneSwarm/blob/master/oneswarm_gwt_ui/src/edu/washington/cs/oneswarm/ui/gwt/server/handlers/FileHandler.java
