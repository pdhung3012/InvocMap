Long.parseLong(inserted.getLastPathSegment())
convert inserted.getLastPathSegment() to Long
parseLong
