new FileInputStream(filePath).getFD()
return FileDescriptor object that represents the connection to the File being used by new FileInputStream(filePath)
getFD
