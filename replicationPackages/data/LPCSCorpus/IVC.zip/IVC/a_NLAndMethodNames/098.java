ftSession.getTransaction().begin()
start a resource transaction for ftSession.getTransaction()
begin
