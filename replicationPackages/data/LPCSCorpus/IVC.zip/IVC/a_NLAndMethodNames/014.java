Arrays.asList(pattern.split("\\[[^\\]]*\\]"))
return List of pattern.split("\\[[^//]]*\\]") for Arrays
asList
630-735
https://github.com/CESNET/perun/blob/master/perun-core/src/main/java/cz/metacentrum/perun/core/impl/Utils.java
