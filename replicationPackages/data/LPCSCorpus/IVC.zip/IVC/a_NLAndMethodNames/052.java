Modifier.isStatic(mLoader.getClass().getModifiers()
return whether mLoader.getClass().getModifiers() is a static Modifier
isStatic
