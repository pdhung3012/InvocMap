session.getTransaction().commit()
flush and end the unit of work for session.getTransaction()
commit
