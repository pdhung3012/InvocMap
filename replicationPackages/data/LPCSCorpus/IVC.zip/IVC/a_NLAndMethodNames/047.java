Intent.ACTION_VIEW.equals(intent.getAction())
return whether Intent.ACTION_VIEW equals intent.getAction()
equals
