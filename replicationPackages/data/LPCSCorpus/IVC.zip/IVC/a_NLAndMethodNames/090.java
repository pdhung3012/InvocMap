Math.max(mPreviewText.getMeasuredWidth(), key.width+mPreviewText.getPaddingLeft() + mPreviewText.getPaddingRight())
return the max of mPreviewText.getMeasuredWidth() and key.width + mPreviewText.getPaddingLeft() + mPreviewText.getPaddingRight()
max
