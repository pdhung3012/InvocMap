tableComponent.getInputMap().put(KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0), "downArrow")
associate key Keystroke.getKeyStroke(KeyEvent.VK_ENTER, 0) with value "downArrow" in tableComponent.getInputMap()
put
