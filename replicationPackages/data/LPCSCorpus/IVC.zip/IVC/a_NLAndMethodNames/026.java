String.valueOf(usd.getSystemUserId())
return string representation of usd.getSystemUserId() for String
valueOf
