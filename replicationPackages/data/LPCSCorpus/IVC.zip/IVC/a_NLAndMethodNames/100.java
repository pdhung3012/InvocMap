Persistence.createEntityManagerFactory( "options" )
create and return EntityManagerFactory for "options" using Persistence
createEntityManagerFactory
