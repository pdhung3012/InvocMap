(Integer.valueOf(id)).intValue()
return Integer representation of Integer.valueOf(id)
intValue
