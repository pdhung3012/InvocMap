new PropertyCombinations(module.getProperties(), module.getActiveLinkerNames()).collapseProperties().size()
return the size of new PropertyCombinations(module.getProperties(),module.getActiveLinkerNames()).collapseProperties()
size
