UnicodeTeX.getMap().containsKey(uCode)
return whether there contains a mapping to key uCode in UnicodeTeX.getMap()
containsKey
1096-1240
https://github.com/geogebra/geogebra/blob/master/common/src/main/java/org/geogebra/common/export/pstricks/GeoGebraToPgf.java
