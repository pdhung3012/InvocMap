dc.getConnection().setAutoCommit(false)
return the current auto commit mode for dc.getConnection()
setAutoCommit
