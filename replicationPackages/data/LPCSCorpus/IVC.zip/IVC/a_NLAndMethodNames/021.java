listIdentifiersMap.put("headers", headers.iterator())
associate key "headers" with value headers.iterator() in listIdentifiersMap
put
