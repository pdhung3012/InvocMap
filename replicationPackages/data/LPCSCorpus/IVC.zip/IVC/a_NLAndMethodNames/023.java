consumofaturadoMes.setScale(0,BigDecimal.ROUND_HALF_UP)
return 0 scale and BigDecimal.ROUND_HALF_UP rounding for consumofaturadoMes
setScale
