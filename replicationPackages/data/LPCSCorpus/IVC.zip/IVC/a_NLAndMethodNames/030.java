java.time.LocalDateTime.of(val.getYear(), val.getMonthOfYear(), val.getDayOfMonth(), val.getHourOfDay(), val.getMinuteOfHour())
obtain instance of LocalDateTime from val.getYear() val.getMonthOfYear() val.getDayOfMonth(), val.getHourOfDay() val.getMinuteOfHour() for LocalDateTime
of
