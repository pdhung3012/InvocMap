expressions.subList(0, expressions.size() - 1))
return new List from index 0 to expressions.size() - 1 in expressions
subList
