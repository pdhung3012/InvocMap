child.getChildren().iterator().next()
return whether there are more elements in child.getChildren().iterator()
next
