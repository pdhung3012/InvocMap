Character.isLowerCase(key.charAt(0)
return whether key.charAt(0) is lower case for Character
isLowerCase
