new Random().nextInt(iterationWeight)
return random number with max value iterationWeight for Random
nextInt
