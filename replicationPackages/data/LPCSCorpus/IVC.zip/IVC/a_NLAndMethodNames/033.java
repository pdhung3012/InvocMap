Math.sqrt(minDelta)
return square root of minDelta for Math
sqrt
