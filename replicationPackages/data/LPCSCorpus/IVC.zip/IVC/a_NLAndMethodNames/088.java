Math.min(Math.abs(frame.top - containerCoordsY),Math.abs(containerCoordsY - frame.bottom))
return the minimum of Math.abs(frame.top - containerCoordsY) and Math.abs(containerCoordsY - frame.bottom)
min
