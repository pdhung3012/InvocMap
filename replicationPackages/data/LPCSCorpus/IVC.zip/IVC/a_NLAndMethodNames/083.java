Integer.parseInt(metaCursor.getString(1))
parse metaCursor.getString(1) to Integer
parseInt
