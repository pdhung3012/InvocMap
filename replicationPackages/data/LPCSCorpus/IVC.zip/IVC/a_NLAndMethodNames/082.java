Thread.sleep((long)(ViewConfiguration.getLongPressTimeout() * 1.5f))
sleep Thread for (long)(ViewConfiguration.getLongPressTimeout() * 1.5 )
sleep
