toggleableRadios.contains(Settings.System.RADIO_BLUETOOTH)
return whether Settings.System.RADIO_BLUETOOTH contains char sequence for toggleableRadios
contains
