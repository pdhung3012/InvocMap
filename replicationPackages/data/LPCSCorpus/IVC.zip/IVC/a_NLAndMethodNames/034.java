event.getFile().getAbsolutePath()
return absolute pathname for event.getFile()
getAbsolutePath
