DriverManager.getConnection(jdbcUrl, DbUser, DbPwd)
attempt to establish connection to given jdbcUrl DbUser DbPwd for DriverManager
getConnection
