Thread.currentThread().getName()
return the String name of the Thread.currentThread()
getName
