System.setOut(new PrintStream(baos))
reassign standard output stream to new PrintStream(baos) for System
setOut
1592-1769
https://github.com/Internet2/grouper/blob/master/grouper-ws/grouper-ws/src/test/edu/internet2/middleware/grouperClient/poc/GrouperClientWsTest.java
