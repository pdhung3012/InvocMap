Collections.binarySearch(alarmList, alarm, mIncreasingTimeOrder)
search alarmList for alarm using binary search with mIncreasingTimeOrder comparator for Collections
binarySearch
