ntraceThreshold.get(ce.getKey())
return the value at key ce.getKey() in ntraceThreshold
get
405-472
https://github.com/kuali/rice/blob/master/rice-framework/krad-web-framework/src/main/java/org/kuali/rice/krad/uif/util/ProcessLogger.java
