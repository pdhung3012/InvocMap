obj.get( "field" ).isString().stringValue().equals( fieldName )
return whether obj.get("field").isString().stringValue equals fieldName
equals
