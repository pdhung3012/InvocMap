 value.add(BigDecimal.valueOf(repaymentScheduleInstallment.getTotal()))
add BigDecimal.valueOf(repaymentScheduleInstallment.getTotal()) to value
add
