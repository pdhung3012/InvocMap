Locale.getDefault()
return current value of default Locale
getDefault
