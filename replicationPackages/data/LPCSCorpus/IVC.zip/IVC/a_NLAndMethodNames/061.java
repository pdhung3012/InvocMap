((String) convertView.getTag()).equals("double")
return whether ((String) convertView.getTag() equals "double"
equals
