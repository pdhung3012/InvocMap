Environment.getExternalStorageDirectory().toString()
return the String representation of Environment.getExternalStorageDirectory()
toString
