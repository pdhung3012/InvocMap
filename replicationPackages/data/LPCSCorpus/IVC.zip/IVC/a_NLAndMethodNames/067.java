StyleConstants.setFontSize(att,14)
set the font size of att to 14 for StyleConstrants
setFontSize
