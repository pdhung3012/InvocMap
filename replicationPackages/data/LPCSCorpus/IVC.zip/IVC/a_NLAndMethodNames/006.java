System.out.println(System.currentTimeMillis() - time);
print System.currentTimeMillis() - time to Standard Output
print
414-481
https://github.com/CSEMike/OneSwarm/blob/master/az_src/src/org/gudy/azureus2/core3/util/LightHashMap.java
