random.nextInt(colors.length)
return a random number with maximum value colors.length
nextInt
