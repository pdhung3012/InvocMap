Runtime.getRuntime().gc()
Run garbage collector for Runtime.getRuntime() for Runtime
gc
