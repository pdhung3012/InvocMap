Locale.LanguageRange.parse(languages)
parse languages to generate a Language Priority List for Locale.LanguageRange
parse
