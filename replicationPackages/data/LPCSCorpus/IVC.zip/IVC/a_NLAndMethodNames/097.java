constraintViolations.iterator().next().getPropertyPath()
return the property path for constrainViolations.iterator().next()
getPropertyPath
