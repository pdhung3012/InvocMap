html.append(token.getRawText())
append token.getRawText() to html
append
1240-1327
https://github.com/tmobile/themes-platform-frameworks-base/blob/2.3.1_r1/core/java/com/google/android/util/AbstractMessageParser.java
